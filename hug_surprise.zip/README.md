# Hug Surprise
A cute click-through surprise built with Next.js, Tailwind CSS, and framer-motion.